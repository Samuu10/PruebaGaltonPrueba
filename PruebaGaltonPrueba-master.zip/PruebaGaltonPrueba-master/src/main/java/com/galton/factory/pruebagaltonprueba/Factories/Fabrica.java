package com.galton.factory.pruebagaltonprueba.Factories;

import com.galton.factory.pruebagaltonprueba.Models.Component;

//Interfaz que representa una fabrica de componentes
public interface Fabrica {
    Component crearComponente();
}