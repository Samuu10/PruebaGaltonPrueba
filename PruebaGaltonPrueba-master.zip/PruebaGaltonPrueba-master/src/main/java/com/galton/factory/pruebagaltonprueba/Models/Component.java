package com.galton.factory.pruebagaltonprueba.Models;

import javafx.scene.layout.Pane;

//Interfaz que representa un componente
public interface Component {
    void dibujar(Pane root);
}